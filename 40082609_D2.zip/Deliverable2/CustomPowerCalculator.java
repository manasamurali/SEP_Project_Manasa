import java.util.Scanner;
/**
 * This class is used to calculate the power of the function
 * without using library functions in java.
 * @author Manasa
 * @version 1.0
 * @since 1.0
 */

public class CustomPowerCalculator {

  private static Scanner sc;

  /**
   * This method is used to calculate the power of positive and negative numbers.
   * @param x Here x is the base.
   * @param y Here y is the exponent.
   * @return rtnVal is returned after calculating the power.
   */

  static float power(float x, float y) {
    if (y == 0) {
      return 1;
    } else {
      float rtnVal = 1;
      Double absoluteValue = getAbsoluteValue(y);
      for (int i = 0; i < absoluteValue.intValue(); i++) {
        rtnVal *= getAbsoluteValue(x);
      }
      return rtnVal;
    }
  }

  /**
   * This method is used to calculate the power in terms of fractions, decimals etc.
   * @param x Here x is the base
   * @param y Here y is the exponent
   * @return result is returned in different ways according to the input values provided
   */
  static double calculatePower(float x, float y) {
    double result = 1;
    int fractionDenominator = 1;
    while ((y * fractionDenominator) != (int) (y * fractionDenominator)) {
      fractionDenominator++;
    }
    float newY = (y * fractionDenominator);
    if (fractionDenominator > 1) {
      result = (float) calculateNthRoot(fractionDenominator, power(x, newY));
      if (newY < 0) {
        result = 1 / result;
      }
    } else {
      result = power(x, y);
      if (newY < 0) {
        result = (1 / result);
      }
    }
    if ((x < 0) && (newY % 2 != 0)) {
      return -result;
    } else {
      return result;
    }
  }

  /**
   * This method is used to parse the fraction that is got as an input.
   * @param ratio This is the fraction input that is given.
   * @return The parsed value is now returned.
   */
  static double parseFraction(String ratio) {
    if (ratio.contains("/")) {
      String[] rat = ratio.split("/");
      return Double.parseDouble(rat[0]) / Double.parseDouble(rat[1]);
    } else {
      return Double.parseDouble(ratio);
    }
  }

  /**
   * Used to calculate the nth root of a number.
   * @param x x is the base.
   * @param y y is the exponent.
   * @return x2 is returned.
   */
  static double calculateNthRoot(float x, float y) {
    return nthroot((int) x, (double) y, .0001);
  }

  /**
   * This method is used to calculate the nth root.
   * @param n integer is passed as parameter where the root is calculated.
   * @param x this is the base.
   * @param p this is exponent.
   * @return
   */
  public static double nthroot(int n, double x, double p) {
    if (x < 0) {
      return -1;
    }
    if (x == 0) {
      return 0;
    }
    double x1 = x;
    double x2 = x / n;
    while (getAbsoluteValue(x1 - x2) > p) {
      x1 = x2;
      x2 = ((n - 1.0) * x2 + x / power((float) x2, (float) (n - 1.0))) / n;
    }
    return x2;
  }

  /**
   * This method is used to calculate the absolute value.
    * @param y y is passed as an argument.
   * @return the absolute value is returned.
   */
  static double getAbsoluteValue(double y) {
    return Double.longBitsToDouble((Double.doubleToLongBits(y) << 1) >>> 1);
  }

  /**
   * This is a test method that calculates the output based on the base and exponent.
   * @param x1 The fraction value is got as a string.
   * @param y1 The fraction value is got as a string.
   * @return either 1 or undetermined or invalid input depending on the input given.
   */
  public static String calculate(String x1, String y1) {

    float x = (float) parseFraction(x1);
    try {
      float y = (float) parseFraction(y1);
      if (x == 0) {
        if (y == 0) {
          return "Undetermined";
        } else {
          return "Infinity";
        }
      } else if (y == 0) {
        return "1";
      } else {
        return (calculatePower(x, y)) + "";
      }
    } catch (Exception e) {
      return "Invalid input";
    }
  }

  /**
   * This method is used to get the input and calculate the output value.
   */
  public static void getInputAndCalculate() {
    sc = new Scanner(System.in);
    System.out.println("Enter values for x & y: ");
    float x = (float) parseFraction(sc.next());
    try {
      float y = (float) parseFraction(sc.next());
      if ((x == 0) && (y <= 0)) {
        System.out.println("Undetermined");

        /*else if ((x < 0) && (y == 0)) {
        System.out.println("-1");*/
      } else {
        System.out.println(calculatePower(x, y));
      }
    } catch (Exception e) {
      System.out.println("Invalid input");
    }
  }

  /**
   * This is the main method of the class used to test the power function.
   * @param args The getInputAndCalculate() method is called here.
   */
  public static void main(String[] args) {
    getInputAndCalculate();
  }
}
