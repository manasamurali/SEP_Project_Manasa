import org.junit.Test;
import static org.junit.Assert.assertEquals;

/**
 * This class contains all the JUnit test cases that are traceable to the requirements
 * @author Manasa
 * @version 1.0
 * @since 1.0
 */
public class TestCustomPowerCalculator {

	public static void AssertValue (double x, double y) {
		System.out.println(Math.pow(x,y));
		 assertEquals(
	    		  Math.pow(x,y), 
	    		  Double.parseDouble(CustomPowerCalculator.calculate(Double.toString(x),Double.toString(y))),
	    		  1);
	}
	public static void AssertExponent (double x, double y, String y1) {
		 assertEquals(
	    		  Math.pow(x,y), 
	    		  Double.parseDouble(CustomPowerCalculator.calculate(Double.toString(x),y1)),
	    		  1);
	}
	
	public static void AssertBase (double x, double y, String x1) {
		 assertEquals(
	    		  Math.pow(x,y), 
	    		  Double.parseDouble(CustomPowerCalculator.calculate(x1,Double.toString(y))),
	    		  1);
	}
	
	public static void AssertFraction(double x, double y, String x1, String y1) {
		 assertEquals(
	    		  Math.pow(x,y), 
	    		  Double.parseDouble(CustomPowerCalculator.calculate(x1,y1)),
	    		  1);
	}
	
	public static void AssertString(String exp, String x,String y) {
		 assertEquals(
	    		  exp, 
	    		  CustomPowerCalculator.calculate(x,y));
	}
	//@SuppressWarnings("deprecation")
	@Test
	   public void testPositiveBaseAndExponent() {
			TestCustomPowerCalculator.AssertValue(3,2);
	   }
	
	@Test
	public void testNegativeBaseAndExponent() {	  
		TestCustomPowerCalculator.AssertValue(-5,-7);
	 }
	
	@Test
	   public void testNegativeBaseAndPositiveExponent() {	  
		TestCustomPowerCalculator.AssertValue(-4,2);

		 }
	
	@Test
	   public void testNegativeBaseAndNegativeExponent() {	  
		TestCustomPowerCalculator.AssertValue(-8,-3);

		 }
	
	
	@Test
	   public void testBase0Exponent0() {	  
		TestCustomPowerCalculator.AssertString("Undetermined","0","0");
 
		 }
	
	@Test
	   public void testExponent0() {	  
		TestCustomPowerCalculator.AssertValue(9,0);

		 }
	
	@Test
	   public void testFractionExponent() {	  
		TestCustomPowerCalculator.AssertExponent(2,2/3,"2/3");

		 }
	
	@Test
	 public void testDecimalExponent() {	  
		TestCustomPowerCalculator.AssertValue(2,0.5);

			 }
	@Test
	   public void testFractionBase() {	  
		TestCustomPowerCalculator.AssertBase(4/5,3,"4/5");
		 }
	
	@Test
	 public void testDecimalBase() {	  
		TestCustomPowerCalculator.AssertValue(6.7,2);

			 }
	
	@Test
	 public void testDecimalBaseAndExponent() {	  
		TestCustomPowerCalculator.AssertValue(6.7,2.5);

			 }
	@Test
	 public void testFractionBaseAndExponent() {	  
		TestCustomPowerCalculator.AssertFraction(6/7,2/3,"6/7","2/3");

			 }
	
	@Test
	 public void testNegativeBaseAndExponent0() {	  
		TestCustomPowerCalculator.AssertValue(-6,0);
	 }
	
	@Test
	 public void testBase0() {	 
		TestCustomPowerCalculator.AssertString("Infinity","0","-6");
	}
	
}
	